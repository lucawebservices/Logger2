# 📬 Notification Logger

A beautiful Android app that silently logs all your notifications to a local database so you can review them even after swiping them away.

## Features

- 🔔 Logs all notifications in the background automatically
- 🎨 Clean, modern UI with colored app avatars
- 🔴 Unread badge counter
- 🏷️ Filter by app using chip tabs
- 👆 Tap to view full notification details
- ↔️ Swipe left to delete individual notifications
- 🗑️ Bulk delete or mark all as read from the menu
- 💾 Persistent SQLite storage — data survives reboots

## How to Build

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Java 8+

### Steps

1. **Open in Android Studio**
   - File → Open → select the `NotificationLogger` folder

2. **Sync Gradle**
   - Click "Sync Now" when prompted, or go to File → Sync Project with Gradle Files

3. **Build the APK**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

4. **Install on your device**
   - Enable "Install from Unknown Sources" on your phone
   - Transfer the APK and tap to install
   - OR use: `adb install app/build/outputs/apk/debug/app-debug.apk`

### First-time Setup

After installing:
1. Open the app
2. A dialog will ask for **Notification Access** — tap "Open Settings"
3. Find "Notification Logger" in the list and enable it
4. Go back to the app — notifications will now be logged automatically!

## How it Works

The app uses Android's `NotificationListenerService` which is a privileged system API that receives a callback every time a notification is posted to any app. It captures the app name, title, body text, and timestamp, then saves it to a local SQLite database.

**Privacy:** All data stays on your device. Nothing is sent anywhere.

package com.notificationlogger;

import android.app.Notification;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class NotificationListenerService extends android.service.notification.NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;

        String packageName = sbn.getPackageName();

        // Skip our own notifications
        if (packageName.equals(getPackageName())) return;

        // Skip system notifications like "USB connected"
        Notification notification = sbn.getNotification();
        if (notification == null) return;
        if ((notification.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;

        Bundle extras = notification.extras;
        if (extras == null) return;

        String title = extras.getString(Notification.EXTRA_TITLE, "");
        CharSequence textCS = extras.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence subTextCS = extras.getCharSequence(Notification.EXTRA_SUB_TEXT);

        String text = textCS != null ? textCS.toString() : "";
        String subText = subTextCS != null ? subTextCS.toString() : "";

        if (title.isEmpty() && text.isEmpty()) return;

        String appName = getAppName(packageName);

        NotificationItem item = new NotificationItem(
                0, appName, packageName, title, text, subText,
                System.currentTimeMillis()
        );

        NotificationDatabase.getInstance(this).insert(item);

        // Broadcast to update UI if open
        sendBroadcast(new android.content.Intent("com.notificationlogger.NEW_NOTIFICATION"));
    }

    private String getAppName(String packageName) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo info = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(info).toString();
        } catch (Exception e) {
            return packageName;
        }
    }
}

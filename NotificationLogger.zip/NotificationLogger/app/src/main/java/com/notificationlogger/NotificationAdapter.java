package com.notificationlogger;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<NotificationItem> items;
    private Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onDelete(int position, NotificationItem item);
        void onClick(NotificationItem item);
    }

    public NotificationAdapter(Context context, List<NotificationItem> items, OnItemClickListener listener) {
        this.context = context;
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_notification, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        NotificationItem item = items.get(position);

        h.tvAppInitial.setText(item.getAppInitial());
        h.tvAppName.setText(item.appName);
        h.tvTitle.setText(item.title);
        h.tvText.setText(item.text);
        h.tvTime.setText(item.getFormattedTime());

        // Color the avatar based on app name
        int[] colors = {
                0xFF6C63FF, 0xFF4CAF50, 0xFFFF5722, 0xFF2196F3,
                0xFFFF9800, 0xFF9C27B0, 0xFF00BCD4, 0xFFE91E63
        };
        int colorIndex = Math.abs(item.appName.hashCode()) % colors.length;
        h.tvAppInitial.setBackgroundColor(colors[colorIndex]);

        // Unread styling
        if (!item.isRead) {
            h.itemView.setAlpha(1.0f);
            h.unreadDot.setVisibility(View.VISIBLE);
        } else {
            h.itemView.setAlpha(0.7f);
            h.unreadDot.setVisibility(View.GONE);
        }

        if (item.text == null || item.text.isEmpty()) {
            h.tvText.setVisibility(View.GONE);
        } else {
            h.tvText.setVisibility(View.VISIBLE);
        }

        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(item);
        });

        h.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(h.getAdapterPosition(), item);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void updateItems(List<NotificationItem> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAppInitial, tvAppName, tvTitle, tvText, tvTime, btnDelete;
        View unreadDot;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAppInitial = itemView.findViewById(R.id.tv_app_initial);
            tvAppName = itemView.findViewById(R.id.tv_app_name);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvText = itemView.findViewById(R.id.tv_text);
            tvTime = itemView.findViewById(R.id.tv_time);
            btnDelete = itemView.findViewById(R.id.btn_delete);
            unreadDot = itemView.findViewById(R.id.unread_dot);
        }
    }
}

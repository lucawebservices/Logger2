package com.notificationlogger;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private NotificationAdapter adapter;
    private NotificationDatabase db;
    private TextView tvEmpty;
    private TextView tvUnreadCount;
    private ChipGroup chipGroup;
    private String currentFilter = null;

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refreshNotifications();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = NotificationDatabase.getInstance(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recycler_view);
        tvEmpty = findViewById(R.id.tv_empty);
        tvUnreadCount = findViewById(R.id.tv_unread_count);
        chipGroup = findViewById(R.id.chip_group);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<NotificationItem> items = db.getAll(currentFilter);
        adapter = new NotificationAdapter(this, items, new NotificationAdapter.OnItemClickListener() {
            @Override
            public void onDelete(int position, NotificationItem item) {
                db.delete(item.id);
                refreshNotifications();
                Snackbar.make(recyclerView, "Notification deleted", Snackbar.LENGTH_SHORT).show();
            }

            @Override
            public void onClick(NotificationItem item) {
                db.markRead(item.id);
                showDetailDialog(item);
                refreshNotifications();
            }
        });

        recyclerView.setAdapter(adapter);

        // Swipe to delete
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView,
                                  @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int pos = viewHolder.getAdapterPosition();
                NotificationItem item = adapter.items.get(pos);
                db.delete(item.id);
                refreshNotifications();
                Snackbar.make(recyclerView, "Deleted", Snackbar.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        checkPermission();
        loadAppFilters();
    }

    private void checkPermission() {
        if (!isNotificationListenerEnabled()) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission Required")
                    .setMessage("Notification Logger needs access to your notifications to log them.\n\nTap OK to open settings, then enable 'Notification Logger'.")
                    .setPositiveButton("Open Settings", (d, w) -> {
                        startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private boolean isNotificationListenerEnabled() {
        String flat = Settings.Secure.getString(getContentResolver(),
                "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    private void loadAppFilters() {
        chipGroup.removeAllViews();

        Chip allChip = new Chip(this);
        allChip.setText("All");
        allChip.setCheckable(true);
        allChip.setChecked(currentFilter == null);
        allChip.setOnClickListener(v -> {
            currentFilter = null;
            refreshNotifications();
            loadAppFilters();
        });
        chipGroup.addView(allChip);

        List<String> apps = db.getDistinctApps();
        for (String entry : apps) {
            String[] parts = entry.split("\\|");
            String appName = parts[0];
            String pkg = parts.length > 1 ? parts[1] : parts[0];

            Chip chip = new Chip(this);
            chip.setText(appName);
            chip.setCheckable(true);
            chip.setChecked(pkg.equals(currentFilter));
            String finalPkg = pkg;
            chip.setOnClickListener(v -> {
                currentFilter = finalPkg;
                refreshNotifications();
                loadAppFilters();
            });
            chipGroup.addView(chip);
        }
    }

    private void refreshNotifications() {
        List<NotificationItem> items = db.getAll(currentFilter);
        adapter.updateItems(items);
        updateEmptyState(items);
        updateUnreadBadge();
    }

    private void updateEmptyState(List<NotificationItem> items) {
        if (items.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void updateUnreadBadge() {
        int unread = db.getUnreadCount();
        if (unread > 0) {
            tvUnreadCount.setVisibility(View.VISIBLE);
            tvUnreadCount.setText(unread > 99 ? "99+" : String.valueOf(unread));
        } else {
            tvUnreadCount.setVisibility(View.GONE);
        }
    }

    private void showDetailDialog(NotificationItem item) {
        String message = "App: " + item.appName +
                "\nTime: " + item.getFormattedTime();
        if (!item.title.isEmpty()) message += "\nTitle: " + item.title;
        if (!item.text.isEmpty()) message += "\n\n" + item.text;
        if (item.subText != null && !item.subText.isEmpty()) message += "\n\n" + item.subText;

        new AlertDialog.Builder(this)
                .setTitle(item.appName)
                .setMessage(message)
                .setPositiveButton("Close", null)
                .setNegativeButton("Delete", (d, w) -> {
                    db.delete(item.id);
                    refreshNotifications();
                })
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_mark_all_read) {
            db.markAllRead();
            refreshNotifications();
            Snackbar.make(recyclerView, "All marked as read", Snackbar.LENGTH_SHORT).show();
            return true;
        } else if (item.getItemId() == R.id.action_clear_all) {
            new AlertDialog.Builder(this)
                    .setTitle("Clear All")
                    .setMessage("Delete all logged notifications?")
                    .setPositiveButton("Delete All", (d, w) -> {
                        db.deleteAll();
                        refreshNotifications();
                        loadAppFilters();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        } else if (item.getItemId() == R.id.action_permission) {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(receiver, new IntentFilter("com.notificationlogger.NEW_NOTIFICATION"));
        refreshNotifications();
        loadAppFilters();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
    }
}

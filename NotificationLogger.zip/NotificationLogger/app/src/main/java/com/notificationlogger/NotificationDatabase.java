package com.notificationlogger;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class NotificationDatabase extends SQLiteOpenHelper {

    private static final String DB_NAME = "notifications.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "notifications";

    private static NotificationDatabase instance;

    public static synchronized NotificationDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new NotificationDatabase(context.getApplicationContext());
        }
        return instance;
    }

    private NotificationDatabase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "app_name TEXT," +
                "package_name TEXT," +
                "title TEXT," +
                "text TEXT," +
                "sub_text TEXT," +
                "timestamp INTEGER," +
                "is_read INTEGER DEFAULT 0" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long insert(NotificationItem item) {
        ContentValues cv = new ContentValues();
        cv.put("app_name", item.appName);
        cv.put("package_name", item.packageName);
        cv.put("title", item.title);
        cv.put("text", item.text);
        cv.put("sub_text", item.subText);
        cv.put("timestamp", item.timestamp);
        cv.put("is_read", 0);
        return getWritableDatabase().insert(TABLE, null, cv);
    }

    public List<NotificationItem> getAll(String filterPackage) {
        List<NotificationItem> list = new ArrayList<>();
        String where = filterPackage != null ? "package_name=?" : null;
        String[] args = filterPackage != null ? new String[]{filterPackage} : null;
        Cursor c = getReadableDatabase().query(TABLE, null, where, args,
                null, null, "timestamp DESC");
        while (c.moveToNext()) {
            NotificationItem item = new NotificationItem();
            item.id = c.getLong(c.getColumnIndexOrThrow("id"));
            item.appName = c.getString(c.getColumnIndexOrThrow("app_name"));
            item.packageName = c.getString(c.getColumnIndexOrThrow("package_name"));
            item.title = c.getString(c.getColumnIndexOrThrow("title"));
            item.text = c.getString(c.getColumnIndexOrThrow("text"));
            item.subText = c.getString(c.getColumnIndexOrThrow("sub_text"));
            item.timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"));
            item.isRead = c.getInt(c.getColumnIndexOrThrow("is_read")) == 1;
            list.add(item);
        }
        c.close();
        return list;
    }

    public void markRead(long id) {
        ContentValues cv = new ContentValues();
        cv.put("is_read", 1);
        getWritableDatabase().update(TABLE, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public void markAllRead() {
        ContentValues cv = new ContentValues();
        cv.put("is_read", 1);
        getWritableDatabase().update(TABLE, cv, null, null);
    }

    public void delete(long id) {
        getWritableDatabase().delete(TABLE, "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteAll() {
        getWritableDatabase().delete(TABLE, null, null);
    }

    public int getUnreadCount() {
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM " + TABLE + " WHERE is_read=0", null);
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }

    public List<String> getDistinctApps() {
        List<String> apps = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT DISTINCT app_name, package_name FROM " + TABLE + " ORDER BY app_name", null);
        while (c.moveToNext()) {
            apps.add(c.getString(0) + "|" + c.getString(1));
        }
        c.close();
        return apps;
    }
}

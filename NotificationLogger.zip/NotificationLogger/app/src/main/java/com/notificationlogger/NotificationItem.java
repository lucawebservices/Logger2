package com.notificationlogger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotificationItem {
    public long id;
    public String appName;
    public String packageName;
    public String title;
    public String text;
    public String subText;
    public long timestamp;
    public boolean isRead;

    public NotificationItem() {}

    public NotificationItem(long id, String appName, String packageName,
                            String title, String text, String subText, long timestamp) {
        this.id = id;
        this.appName = appName;
        this.packageName = packageName;
        this.title = title;
        this.text = text;
        this.subText = subText;
        this.timestamp = timestamp;
        this.isRead = false;
    }

    public String getFormattedTime() {
        long now = System.currentTimeMillis();
        long diff = now - timestamp;

        if (diff < 60_000) return "Just now";
        if (diff < 3_600_000) return (diff / 60_000) + "m ago";
        if (diff < 86_400_000) return (diff / 3_600_000) + "h ago";

        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, h:mm a", Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public String getAppInitial() {
        if (appName != null && !appName.isEmpty()) {
            return String.valueOf(appName.charAt(0)).toUpperCase();
        }
        return "?";
    }
}
